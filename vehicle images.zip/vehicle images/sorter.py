import os

# Define the path to the directory containing the images
directory = 'vehicle images'

# Get list of all files in the directory
files = [f for f in os.listdir(directory) if os.path.isfile(os.path.join(directory, f))]

# Sort files to maintain a consistent renaming order
files.sort()

# Rename files
for i, filename in enumerate(files):
    # New file name
    new_name = f'car{i+1}.jpg'
    
    # Construct full file paths
    old_file = os.path.join(directory, filename)
    new_file = os.path.join('Images', new_name)
    
    # Rename the file
    os.rename(old_file, new_file)
    
    print(f'Renamed {filename} to {new_name}')
